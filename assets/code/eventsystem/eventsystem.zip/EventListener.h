#ifndef _EVENTLISTENER_H_
#define _EVENTLISTENER_H_

class IEventListener
{
protected:
	IEventListener( void )
	{}
};

#endif // _EVENTLISTENER_H_